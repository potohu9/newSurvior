﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	private static int MAX_HP = 100;

	private GameObject player;
	private GameObject background;
	private Animator animator;

	GameObject temp;
	Transform transform;
	PlayerStatus status;

	public GameObject attackEff;
	public GameObject hitEff;
	public GameObject deathEff;

	private float interval = 1;
	private float count = 0;

	// Use this for initialization
	void Start () {
		player = GameObject.Find ("Player");
		//background = GameObject.Find ("Back1");
		background = GameObject.Find ("Terrain 1");
		animator = player.GetComponent<Animator> ();

		/*temp = Instantiate(Resources.Load("Prefabs/movetraget/movetragetsprite"),new Vector3(0, 0.1f, 0),Quaternion.identity) as GameObject;
		transform = temp.GetComponent<Transform> ();
		transform.position = new Vector3(0,-1,0);*/

		GameObject obj = GameObject.Find("Player");

		status = obj.GetComponent<PlayerStatus> ();

		status.HP = MAX_HP;
		status.AT = 5;
		status.DF = 0;
		status.SP = 10;
	}
	
	// Update is called once per frame
	void Update () {
		// rigidbodyを常時有効にし続ける（重かったら別の方法考える）
		gameObject.GetComponent<Rigidbody>().WakeUp();

		if (Input.touchCount > 0) {
			if(Input.GetTouch (0).phase == TouchPhase.Began
			|| Input.GetTouch (0).phase == TouchPhase.Stationary
			|| Input.GetTouch (0).phase == TouchPhase.Moved) {
				Ray ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
				RaycastHit hit;

				if(background.collider.Raycast (ray, out hit, 1000)) {

					// 移動
					Vector3 target = new Vector3 (hit.point.x, hit.point.y, hit.point.z);
					Vector3 temp = target - player.transform.position;
					Vector3 nor = temp.normalized;

					Vector3 pos = nor * status.SP;

					player.rigidbody.AddForce(
						pos,
						ForceMode.Impulse);

					float rad = Mathf.Atan2((hit.point.x - player.transform.position.x), (hit.point.z - player.transform.position.z));

					// 向き
					player.transform.rotation = Quaternion.Euler (0, rad * Mathf.Rad2Deg, 0);

					// アニメーション
					animator.SetBool ("isRunning",true);
				}
				/*transform.position = new Vector3(hit.point.x, 0.1f, hit.point.z);
			} else {
				transform.position = new Vector3(0,-1,0);
			}*/
			}
			if(Input.GetTouch (0).phase == TouchPhase.Ended) {
				Vector3 vel = Vector3.zero;
				player.rigidbody.AddForce(
					vel,
					ForceMode.Impulse);
				animator.SetBool ("isRunning", false);
			}
		}

		if (Input.GetMouseButton (0)) {
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			RaycastHit hit;
			
			if(background.collider.Raycast (ray, out hit, 1000)) {
				
				// 移動
				Vector3 target = new Vector3 (hit.point.x, hit.point.y, hit.point.z);
				Vector3 temp = target - player.transform.position;
				Vector3 nor = temp.normalized;
			
				Vector3 pos = nor * status.SP;
				
				player.rigidbody.AddForce(
					pos,
					ForceMode.Impulse);
				
				float rad = Mathf.Atan2((hit.point.x - player.transform.position.x), (hit.point.z - player.transform.position.z));
				
				// 向き
				player.transform.rotation = Quaternion.Euler (0, rad * Mathf.Rad2Deg, 0);
				
				// アニメーション
				animator.SetBool ("isRunning",true);
			}
		}

		count += Time.deltaTime;
	}

	public float getHpRate() {
		return (float)status.HP / MAX_HP;
	}

	public void damage(int damage) {
		status.HP -= damage - (int)status.DF;

		if(status.HP > 0) {
			// Hit Effect
			Instantiate (hitEff, gameObject.transform.position, Quaternion.identity);
		}
		else {
			// GameOver
			Instantiate (deathEff, gameObject.transform.position, Quaternion.identity);
		}
	}

	void OnCollisionStay(Collision collision) {
		if(count >= interval) {
			if(collision.gameObject.tag == "Enemy") {
				Vector3 pos = player.transform.position;
				pos.y = 0.2f;
				float rad = Mathf.Atan2((collision.gameObject.transform.position.x - player.transform.position.x), (collision.gameObject.transform.position.z - player.transform.position.z));

				Instantiate (attackEff, pos, Quaternion.Euler (0, rad * Mathf.Rad2Deg - 180, 0));

				collision.gameObject.GetComponentInChildren<enemyMoveController>().damage (status.AT);

				count = 0;
			}
		}
	}

}
