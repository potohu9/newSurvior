﻿using UnityEngine;
using System.Collections;

public class LookOnObject : MonoBehaviour {

	public GameObject lookOutPrefab;
	private bool isMakedPrefab = false;

	public void lookOut(){
		makePrefab();
		Destroy(gameObject);
	}

	private void makePrefab(){
		if(!isMakedPrefab){
			GameObject parent = gameObject.transform.parent.gameObject;
			GameObject lookOut = GameObject.Instantiate(lookOutPrefab,gameObject.transform.position,gameObject.transform.rotation) as GameObject;
			isMakedPrefab = true;
			lookOut.transform.parent = parent.transform;
			Destroy(gameObject);
		}
	}
}
