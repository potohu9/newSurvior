﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HPmeterScript : MonoBehaviour {

	private Image image;
	private PlayerController script;
	public GameObject player;



	// Use this for initialization
	void Start () {
		image = GetComponent<Image>();
		player = GameObject.Find ("Player");
		script = player.GetComponent<PlayerController> ();
	}

	// Update is called once per frame
	void Update () {
		image.fillAmount = script.getHpRate();
	}
}
