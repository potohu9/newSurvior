﻿using UnityEngine;
using System.Collections;

public class LookOutObject : MonoBehaviour {
	public void deleat(){
		GameObject parent = gameObject.transform.parent.gameObject;
		LookOutObject parentComponent = parent.GetComponent<LookOutObject>();
		parentComponent.parentDeleat();
		Destroy(gameObject);
	}
	
	private void parentDeleat(){
		Destroy(gameObject);
	}
}
