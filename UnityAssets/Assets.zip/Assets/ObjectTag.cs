﻿using UnityEngine;
using System.Collections;

/**
 * タグをここで一括で取り扱うっぽい事をするかも知れないクラス
 * 頭文字は大文字で統一
 */
public class ObjectTag {
	public static string PLAYER = "Player";
	public static string ENEMY  = "Enemy";
	public static string WALL   = "Wall";
}

