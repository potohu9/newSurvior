﻿using UnityEngine;
using System.Collections;

public class ParticleController : MonoBehaviour {
	void LateUpdate (){
		if(!particleSystem.IsAlive()){
			Destroy (gameObject);
		}
	}
}
