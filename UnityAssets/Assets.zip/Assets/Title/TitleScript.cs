﻿using UnityEngine;
using System.Collections;

public class TitleScript : MonoBehaviour {
	public void nextScene(){
		Application.LoadLevel("test");
	}
}
