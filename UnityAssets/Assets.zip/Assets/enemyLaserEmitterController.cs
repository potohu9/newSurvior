﻿using UnityEngine;
using System.Collections;

public class enemyLaserEmitterController : MonoBehaviour {

	private GameObject player;
	public string playerTag = "Player";

	// Use this for initialization
	void Start () {
		player = GameObject.FindWithTag(playerTag);
	}
	
	// Update is called once per frame
	void Update () {
		gameObject.transform.LookAt(player.transform.position);
	}
}