﻿using UnityEngine;
using System.Collections;

public class LaserController : MonoBehaviour {
	public float speed = 150.0f;
	public ParticleSystem effect;
	// Use this for initialization
	void Start () {
		gameObject.rigidbody.AddForce(transform.forward * speed,ForceMode.VelocityChange);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision collision){
		if (collision.gameObject.tag == "Player") {
			collision.gameObject.GetComponent<PlayerController>().damage (10);
		}

		effect.Stop();
		gameObject.transform.DetachChildren();
		Destroy(gameObject);
	}
}
