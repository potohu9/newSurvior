﻿using UnityEngine;
using System.Collections;

public class circleAttackController : MonoBehaviour {

	public float repelPower = 1;
	public int power = 1;

	void OnCollisionEnter(Collision collision){
		if (collision.gameObject.tag == "Player") {
			collision.gameObject.GetComponent<PlayerController>().damage (10);
		}
	}
}
