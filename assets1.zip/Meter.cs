﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Meter : MonoBehaviour {

	private Image image;
	private enemyMoveController script;
	public GameObject player;
	private int max;
	
	
	
	// Use this for initialization
	void Start () {
		image = GetComponent<Image>();
		player = GameObject.FindWithTag ("Enemy");
		script = player.GetComponentInChildren<enemyMoveController> ();
		max = script.hp;
	}
	
	// Update is called once per frame
	void Update () {
		image.fillAmount = (float)script.hp / max;
	}
}
