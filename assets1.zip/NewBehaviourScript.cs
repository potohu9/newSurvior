﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class NewBehaviourScript : MonoBehaviour {

	public float m_updateInterval = 1.0f;  // 更新される頻度
	float m_accumulated   = 0.0f;
	float m_timeUntilNextInterval; //  次の更新までの残り時間
	int m_numFrames = 0;
	Text hoge;

	// Use this for initialization
	void Start () {
		QualitySettings.vSyncCount = 0; // VSyncをOFFにする
		Application.targetFrameRate = 30; // ターゲットフレームレートを60に設定

		m_timeUntilNextInterval = m_updateInterval;

		hoge = GetComponent<Text>();
		hoge.text = "hoge";
	}
	
	// Update is called once per frame
	void Update () {
		m_timeUntilNextInterval -= Time.deltaTime;
		m_accumulated += Time.timeScale / Time.deltaTime;
		++m_numFrames;

		if( m_timeUntilNextInterval <= 0.0 )
		{
			// FPSの計算と表示
			float fps = m_accumulated / m_numFrames;
			string format = System.String.Format( "FPS: {0:F2}", fps );
			hoge.text = format;

			m_timeUntilNextInterval = m_updateInterval;

			print(format);

			m_accumulated = 0.0F;
			m_numFrames = 0;
		}
	}
}
