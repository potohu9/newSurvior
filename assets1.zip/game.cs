﻿using UnityEngine;
using System.Collections;

public class game : MonoBehaviour {
	public void nextScene(){
		Application.LoadLevel("titleScene");
	}
}
