﻿using UnityEngine;
using System.Collections;

public class testS : MonoBehaviour {

	// Use this for initialization
	void Start () { 
		SoundManager instance = SoundManager.Instance;

		//instance.playBGM (0);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
