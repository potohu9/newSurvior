﻿using UnityEngine;
using System.Collections;

public class enemyHPScript : MonoBehaviour {
	GameObject canvas;
	public GameObject trget;
	public bool tag = false;
	Camera camera;

	public Camera main;
	public Camera sub;
	// Use this for initialization
	void Start () {
		canvas = GameObject.Find ("enemyCanvas");
		transform.parent = canvas.transform;
		transform.localPosition = new Vector3 (0, 0, 0);
		transform.localScale = new Vector3 (1, 1, 1);

		camera = Camera.main;
	}
	
	// Update is called once per frame
	void Update () {
		if(trget!=null){
			Vector3 ObjectPoint = trget.transform.position;

			Vector3 screenPostion = camera.WorldToScreenPoint(ObjectPoint);

			Vector3 pos = new Vector3(screenPostion.x - Screen.width * 0.5f, (Screen.height-screenPostion.y) * -1 + (Screen.height * 0.5f +25.0f), 0);

			//transform.LookAt (camera.transform.position);

			transform.localRotation = Quaternion.Euler (0, 0, 0);

			transform.localPosition = pos;

			/*Vector3 pos = CameraManager.cameras[0].WorldToScreenPoint (trget.transform.position);
			pos.z = 1.0f;
			canvas.transform.position = CameraManager.cameras[1].ScreenToWorldPoint
			*/
		}
	}

	public void setTarget(GameObject t){
		//trget = GameObject.Find (t);
		trget = t;
		tag = true;
	}
}
