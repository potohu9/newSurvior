﻿using UnityEngine;
using System.Collections;

public class LookObjectController : MonoBehaviour {

	public bool isRotateCamera = false;
	public float cameraRotateSpeed = 0.1f;

	private bool isLookOn = false;

	public GameObject lookOnCirclePrefab;

	private GameObject lookOnCircleObject = null;
	
	// Update is called once per frame
	void Update () {
		if (Input.GetMouseButtonDown(0)) {
			if(isLookOn){
				lookOut();
			}
			else{
				lookOn(GameObject.Find("Cube"));
			}
		}

		if(isLookOn){
			gameObject.transform.LookAt(Camera.main.transform.position);
			if(isRotateCamera){
				//Camera.main.transform.LookAt(gameObject.transform.position);
				Camera.main.transform.rotation = Quaternion.Slerp(Camera.main.transform.rotation, Quaternion.LookRotation(gameObject.transform.position - Camera.main.transform.position),cameraRotateSpeed);
			}
		}
	}

	public void lookOn(GameObject target){
		if(!isLookOn){
			gameObject.transform.parent = target.transform;
			gameObject.transform.localPosition = new Vector3();
			lookOnCircleObject = GameObject.Instantiate(lookOnCirclePrefab,gameObject.transform.position,lookOnCirclePrefab.transform.rotation) as GameObject;
			lookOnCircleObject.transform.parent = gameObject.transform;
			lookOnCircleObject.transform.localRotation = lookOnCirclePrefab.transform.rotation;
			isLookOn = true;
		}
	}

	public void lookOut(){
		if(isLookOn){
			LookOnObject component = lookOnCircleObject.GetComponent<LookOnObject>();
			component.lookOut();
			gameObject.transform.parent = null;
			lookOnCircleObject = null;
			isLookOn = false;
		}
	}
}
