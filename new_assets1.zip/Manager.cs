﻿using UnityEngine;
using System.Collections;

public class Manager : MonoBehaviour {

	private GameObject player;	// Bar オブジェクトの取得実験
//	public GameObject circleSign;
	private GameObject background;
	private GameObject query;

	private int count = 80;

	// Use this for initialization
	void Start () {
		// 画面の向きを制御（デフォは横？）
		Screen.orientation = ScreenOrientation.LandscapeLeft; // 縦向き

		player = GameObject.Find ("Player");

//		circleSign = GameObject.Find ("CircleSign");
		// Background
		background = GameObject.Find ("Back1");

		query = GameObject.Find ("bossEnemy1");
	}
	
	// Update is called once per frame
	void Update () {

		/**
		 * -memo-
		 * 
		 *  Began タッチの開始
   		 * 	Ended タッチの終了
    	 *	Moved 移動中
    	 *	Stationary タッチが継続中の場合(非移動中)
    	 *	Canceled タッチがキャンセルになった場合
		 */
	}

	public void setAvtive(bool value) {
		
	}
}
