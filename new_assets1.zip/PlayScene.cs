﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayScene : MonoBehaviour {

	GameObject obj;
	Image[] images;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

	}
}
