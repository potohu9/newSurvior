﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SkikkButtonScript : MonoBehaviour {
	private int ATTACK = 5;
	private uint DEFENCE = 4;
	private float SPEED = 5;

	public GameObject prefab;
	public GameObject target;
	public Image image;
	private Sprite spr;
	public bool pushFlag;

	public uint coolTime = 30;
	public Time timer;
	private float timeS;
	public float duration = 30;	// 持続時間
	
	private static string name;
	private static GameObject player;

	private Skill skill;
	
	PlayerStatus script;
	GameObject type;
	private static GameObject effect;
	bool flag;
	
	void Start () {
		pushFlag = true;
		timeS = 0;

		name = null;

		image = GetComponent<Image>();
		image.sprite = spr;

		GameObject obj = GameObject.Find("Player");
		script = obj.GetComponent<PlayerStatus> ();
		
		type = this.gameObject;
		player = GameObject.Find ("Player");

		setSkill ();
	}

	// ボタンを押した際に呼ばれる関数
	public void Push()
	{
		if(pushFlag==true){
			if(name != null) {
				GameObject.Find (name).GetComponent<SkikkButtonScript>().stopCoroutine();
			}

			name = type.name;

			image.fillAmount = 0;
			pushFlag=false;
			// ボタンが押した際に出力
			//print("Button Push!");

			//カメラとの距離
			skill.Push ();

			timeS = Time.time;	//ゲーム起動から今までの時間

			upStatus ();

			StartCoroutine ("limitDuration");
		}
	}

	void Update () {
		if(pushFlag==false){

			float timeN = Time.time;
			image.fillAmount = (timeN-timeS)/skill.coolTime;

			if(timeN-timeS >= skill.coolTime){
				pushFlag=true;
			}
		}
	}

	IEnumerator limitDuration () {
		yield return new WaitForSeconds (skill.duration);

		downStatus ();

		name = null;
	}

	public void stopCoroutine (){
		StopCoroutine ("limitDuration");

		downStatus ();
	}

	private void upStatus() {
		/*switch(type.name){
		case "skill1button":
			script.AT += ATTACK;
			effect = Instantiate(Resources.Load("Particle/Prefab/Aura"),new Vector3(0, 0.1f, 0),Quaternion.identity) as GameObject;
			break;
		case "skill2button":
			script.DF += DEFENCE;
			break;
		case "skill3button":
			script.SP += SPEED;
			break;
		default:
			script.HP -= 10;
			break;
		}

		effect.transform.position = player.transform.position;
		effect.transform.parent = player.transform;*/
		skill.startEffect ();
	}
	
	private void downStatus() {
		/*switch(name){
		case "skill1button":
			script.AT -= ATTACK;
			break;
		case "skill2button":
			script.DF -= DEFENCE;
			break;
		case "skill3button":
			script.SP -= SPEED;
			break;
		default:
			script.HP -= 10;
			break;
		}

		Destroy (effect);*/
		skill.endEffect ();
	}

	public void setSkill() {
		GameObject obj = GameObject.Find ("SetSkill") as GameObject;
		SetSkillManagerScript script = obj.GetComponent<SetSkillManagerScript> ();

		switch (gameObject.name) {
		case "skill1button":
			skill = script.skill[0];
			break;

		case "skill2button":
			skill = script.skill[1];
			break;

		case "skill3button":
			skill = script.skill[2];
			break;
		}

		Texture2D texture = Resources.Load (skill.skillIconSpritePath) as Texture2D;
		Sprite texture_sprite = Sprite.Create(texture, new Rect(0,0,texture.width,texture.height), Vector2.zero);
		
		image.sprite = texture_sprite;
	}

	IEnumerator coroutine() {
		while (flag) { 
			print (gameObject.name + "コルーチンなう");
			yield return 0; 
		}
	}
		
}
