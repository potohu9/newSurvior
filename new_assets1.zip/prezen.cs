﻿using UnityEngine;
using System.Collections;

public class prezen : MonoBehaviour {

	GameObject obj;
	Animator anime;

	// Use this for initialization
	void Start () {
		obj = GameObject.Find ("unitychan") as GameObject;
		anime = obj.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown (KeyCode.Space)) {
			if(anime.GetInteger ("state") == 0) {
				anime.SetInteger ("state", 4);
			}
			else {
				anime.SetInteger ("state", 0);
			}
		}

		if(Input.GetKey (KeyCode.UpArrow) && Time.timeScale >= 1.0f) {
			print (Time.timeScale);
			Time.timeScale += 0.1f;
		}
		else if(Input.GetKey (KeyCode.DownArrow) && Time.timeScale <= 1.0f) {
			print (Time.timeScale);
			Time.timeScale -= 0.1f;
		}
	}
}
