﻿using UnityEngine;
using System.Collections;

/**
 * 演出の終わったパーティクルだけを殺すクラスかよ！
 */
public class ShurikenParticle : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		print (particleSystem.IsAlive ());
		if (!particleSystem.IsAlive ()) {
			Destroy(gameObject.transform.parent.gameObject);
		}
	}
}
