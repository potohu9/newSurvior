var deadTime : float;

function Awake () {
	Destroy (gameObject, deadTime);
}