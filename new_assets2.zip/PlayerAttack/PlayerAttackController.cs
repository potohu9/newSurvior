﻿using UnityEngine;
using System.Collections;

public class PlayerAttackController : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void Deleate(){
		Destroy(gameObject);
	}
}
