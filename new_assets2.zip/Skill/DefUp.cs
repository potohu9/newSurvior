﻿using UnityEngine;
using System.Collections;

public class DefUp : Skill {

   public DefUp() {
       explanationText = "硬くなる♂";
       invocationEffectPrefabPath = "SkillParticle/Defend_Buf";
       runtimeEffectPrefabPath =    "SkillParticle/Barrier";
       skillIconSpritePath = "SkillIcon/DeffenceUp";
       duration = 30;
       coolTime = 30;
    }

	public override void Push() {
		if (target == null) {
			target = GameObject.Find ("Player");	
		}
		
		GameObject obj = GameObject.Instantiate (Resources.Load (invocationEffectPrefabPath), new Vector3(0, 0.1f, 0), Quaternion.identity) as GameObject;
		obj.transform.position = target.transform.position;
		obj.transform.parent = target.transform;
	}
	
	public override void startEffect() {
		eff = GameObject.Instantiate(Resources.Load(runtimeEffectPrefabPath), new Vector3(0, 0.1f, 0),Quaternion.identity) as GameObject;
		eff.transform.position = target.transform.position;
		eff.transform.parent = target.transform;
	}
	
	public override void endEffect() {
		GameObject.Destroy (eff);
	}
}
