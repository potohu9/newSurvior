﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class DecisionScript : MonoBehaviour {

	private SetSkillManagerScript script;
	private Button botton;
	public bool flag = false;

	// Use this for initialization
	void Start () {
		GameObject manager = GameObject.Find("SetSkill");
		script = manager.GetComponent<SetSkillManagerScript>();

		botton = GetComponent<Button>();
	}
	
	// Update is called once per frame
	void Update () {
		Skill skill1 = script.skill[0];
		Skill skill2 = script.skill[1];
		Skill skill3 = script.skill[2];
		if(script.skill[0]!=null && script.skill[1]!=null && script.skill[2]!=null){
			//押せる
			//botton.interactable = true;
			flag = true;
		} else {
			//押せない
			//botton.interactable = false;
			flag=false;
		}
	}

	public void push(){
		//マネジャからスキル名を貰う
		Skill skill1 = script.skill[0];
		Skill skill2 = script.skill[1];
		Skill skill3 = script.skill[2];
		if(script.skill[0]!=null && script.skill[1]!=null && script.skill[2]!=null){
			//シーン転移
			Application.LoadLevel("test");
		}
	}
}
