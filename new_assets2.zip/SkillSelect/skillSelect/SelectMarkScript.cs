﻿using UnityEngine;
using System.Collections;

public class SelectMarkScript : MonoBehaviour {

	public Vector3 pos;

	// Use this for initialization
	void Start () {
		pos = gameObject.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		//まねじゃから大正を受け取る
		GameObject manager = GameObject.Find("SetSkill");
		SetSkillManagerScript script = manager.GetComponent<SetSkillManagerScript>();
		//大正のオブジェクトの位置
		//位置を修正
		//transform.localPosition = objTrans.localPosition;
		gameObject.transform.position = pos;
	}
}