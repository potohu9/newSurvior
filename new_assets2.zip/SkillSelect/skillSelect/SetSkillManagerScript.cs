﻿using UnityEngine;
using System.Collections;

public class SetSkillManagerScript : MonoBehaviour {

	public Skill setSkill;
	public Skill[] skill;

	// Use this for initialization
	void Start () {
		setSkill = SkillFactory.getSkill ("AttUp");

		skill = new Skill[3];

		DontDestroyOnLoad (gameObject);
	}
	
	// Update is called once per frame
	void Update () {

	}	
}
