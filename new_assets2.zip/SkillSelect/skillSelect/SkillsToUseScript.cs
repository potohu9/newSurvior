﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SkillsToUseScript : MonoBehaviour {

	private SetSkillManagerScript script;
	private GameObject manager;

	public string imageName;
	private Image imageComponent;

	public Sprite sprite;

	// Use this for initialization
	void Start () {
		manager = GameObject.Find("SetSkill");
		script = manager.GetComponent<SetSkillManagerScript>();

		imageComponent = GetComponent<Image> ();
	}

	// Update is called once per frame
	void Update () {
	}

	public void push(){
		//マネジャからスキル名を貰う
		Skill skill = script.setSkill;
		Skill skill1 = script.skill[0];
		Skill skill2 = script.skill[1];
		Skill skill3 = script.skill[2];
		if(skill!=skill1 && skill!=skill2 && skill!=skill3){
			//テクスチャ変更
			Texture2D texture = Resources.Load (skill.skillIconSpritePath)as Texture2D;
			Sprite texture_sprite = Sprite.Create(texture, new Rect(0,0,texture.width,texture.height), Vector2.zero);
			
			imageComponent.sprite = texture_sprite;
			
			//マネジャにセットされたスキル名を送る
			switch(name){
			case "Button1":
				script.skill[0] = script.setSkill;
				break;
			case "Button2":
				script.skill[1] = script.setSkill;
				break;
			case "Button3":
				script.skill[2] = script.setSkill;
				break;
			}
		}
	}
}
