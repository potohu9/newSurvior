﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Reflection;

public class SkillsYouChoseScript : MonoBehaviour {

	private SetSkillManagerScript script;
	private GameObject manager;
	public string skillName;
	private Skill skill;

	// Use this for initialization
	void Start () {
		manager = GameObject.Find("SetSkill");
		script = manager.GetComponent<SetSkillManagerScript>();


		skill = SkillFactory.getSkill (skillName);
		/*
		type = System.Type.GetType (skillName);
		obj = System.Activator.CreateInstance (type);
		string str = type.GetField ("skillIconSpritePath").GetValue(obj) as string;
		*/
		Texture2D texture = Resources.Load (skill.skillIconSpritePath)as Texture2D;
		GetComponent<Image>().sprite = Sprite.Create(texture, new Rect(0,0,texture.width,texture.height), Vector2.zero);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void push(){
		print (skill);
		script.setSkill = skill;
		print (script.setSkill);
		GameObject.Find ("Mark").GetComponent<SelectMarkScript> ().pos = gameObject.transform.position;
		print (gameObject.transform.position);
	}
}
