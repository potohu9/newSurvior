﻿using UnityEngine;
using System.Collections;

public class ResltScript : MonoBehaviour {

	public void nextScene(){
		Application.LoadLevel("titleScene");
	}
}
