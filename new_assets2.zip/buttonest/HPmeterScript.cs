﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class HPmeterScript : MonoBehaviour {

	private Image image;
	private PlayerController script;
	public GameObject player;

	private Image damage;
	private float rate;

	// Use this for initialization
	void Start () {
		image = GetComponent<Image>();
		player = GameObject.Find ("Player");
		script = player.GetComponent<PlayerController> ();

		damage = GameObject.Find ("hpDamage").GetComponent<Image> ();

		rate = 1;
	}

	// Update is called once per frame
	void Update () {
		float playerHp = script.getHpRate ();

		if(playerHp < rate){
			rate -= 0.01f;
		} else if(playerHp > rate){
			rate = playerHp;
		}

		image.fillAmount = playerHp; 
		damage.fillAmount = rate;
	}
}
