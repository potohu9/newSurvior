﻿using UnityEngine;
using System.Collections;

public class LaserController : MonoBehaviour {
	public float speed = 1500000000000.0f;
	public ParticleSystem effect;
	public float repelPower = 1;
	public int power = 1;

	private PlayerController script;

	// Use this for initialization
	void Start () {
		gameObject.rigidbody.AddForce(transform.forward * speed * Time.deltaTime,ForceMode.VelocityChange);

		script = GameObject.Find ("Player").GetComponent<PlayerController> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter(Collider collider) {
		BoxCollider box = collider as BoxCollider;
		MeshCollider mesh = collider as MeshCollider;

		if(box != null || mesh != null) {
			string tag = collider.gameObject.tag;

			if (tag == "Player") {
				script.damage (10);		
			}
		}

		Destroy (gameObject);
	}

}
