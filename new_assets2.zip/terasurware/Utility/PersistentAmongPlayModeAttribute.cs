﻿
using UnityEngine;
using System.Collections;
using System;

[AttributeUsage(AttributeTargets.Field )]
public class PersistentAmongPlayModeAttribute : Attribute {}
